# bitbucket-copy-format
A commit formatter for redmine tasks 

## Features

* Copy and format commits infos

## Usage on Chrome

1. Open `chrome://extensions` in chrome
2. Click load unpacked extension 
3. Select folder wich contains that project
3. Open commit page (like `https://bitbucket.org/*/*/commits/*`)
4. Click in extension button
5. Paste

## Usage on Firefox

1. You can load the
## License

This project is licensed under the terms of the [**MIT**](https://opensource.org/licenses/MIT) license.
